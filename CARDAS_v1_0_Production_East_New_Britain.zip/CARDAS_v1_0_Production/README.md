# CARDAS v1.1 — Package G

**Caritas Rabaul Disaster Assessment System (CARDAS)**

This package continues the CARDAS offline-first field application for the Caritas Rabaul Office and Archdiocese of Rabaul.

## Package G additions

- Local user accounts with roles: administrator, coordinator, assessor and warehouse.
- First-run administrator setup instead of shipping a universal password.
- SHA-256 password hashing for the local account store.
- Audit log for login/logout activity.
- Administration screen for controlled district, parish and village master data.
- JSON backup and restore for operational data.
- Backup export intentionally excludes password hashes/user accounts.
- Durable local synchronization queue for incidents, households and warehouse changes.
- Synchronization status screen documenting the future server hand-off.
- Existing GPS, incident photos, incident map, reporting and CSV/PDF features remain included.
- Existing Caritas Rabaul Office logo and Archdiocese of Rabaul crest are retained unchanged.

## Important master-data note

The seeded parish list in this development package is limited/illustrative. It is **not an authoritative diocesan master list**. Before operational deployment, the Administration module should be populated and verified against the Archdiocese of Rabaul's approved district/parish/village records.

## Offline-first boundary

CARDAS stores assessment records, GPS coordinates and incident photos locally. Package G also stores changes in a local sync queue. **It does not transmit field data to a remote server.** A production synchronization service requires an approved server, user authentication, encryption, conflict-resolution rules, ownership/retention rules and connectivity policy.

Likewise, the incident map's geographic basemap is not claimed to be fully offline. Offline incident records and coordinates are supported; offline basemap tiles require a separate approved tile/caching strategy.

## First run

When the application is started for the first time, create the CARDAS administrator account. Use a strong password and keep it secure.

## Create Flutter platform folders

The development environment used to assemble this source package does not contain the Flutter SDK, so Android and Windows platform folders are not generated here.

On a machine with Flutter installed:

```bash
flutter create . --platforms=android,windows
flutter pub get
flutter run -d windows
```

For Android:

```bash
flutter run -d <android-device>
```

## What is not claimed

This package has not been compiled into an APK or Windows EXE in this environment because Flutter/Dart are unavailable here. The source is therefore a development package, not a build-certified release.

## Branding

The following supplied files are used directly:

- `assets/branding/caritas_rabaul_logo.jpg`
- `assets/branding/archdiocese_rabaul_crest.png`

No replacement organisational branding was created.

## Production operational modules
Distribution stock deduction, volunteer register, emergency shelters, WASH/water sources, recovery projects, parish preparedness, emergency contacts, resource inventory, disaster timeline, and East New Britain Disaster Atlas data structure are included. Atlas records require verification before operational use.
