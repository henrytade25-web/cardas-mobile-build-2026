# CARDAS East New Britain Disaster Atlas

The atlas schema is included, but CARDAS does **not** fabricate parish, village, shelter, health-facility or water-source coordinates. Locations are entered/imported through Administration and should carry a source and verification status.
