import 'package:flutter/material.dart';
import 'database/database_service.dart';
import 'screens/dashboard_screen.dart';
import 'screens/incident_form_screen.dart';
import 'screens/incident_list_screen.dart';
import 'screens/incident_detail_screen.dart';
import 'screens/household_form_screen.dart';
import 'screens/warehouse_screen.dart';
import 'screens/incident_map_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/login_screen.dart';
import 'screens/first_run_screen.dart';
import 'screens/admin_screen.dart';
import 'screens/user_management_screen.dart';
import 'screens/sync_screen.dart';
import 'screens/atlas_screen.dart';
import 'screens/operations_screen.dart';
import 'services/auth_service.dart';
import 'theme/cardas_theme.dart';

class CardasApp extends StatefulWidget { const CardasApp({super.key}); @override State<CardasApp> createState()=>_CardasAppState(); }
class _CardasAppState extends State<CardasApp> {
  bool? hasUsers;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async { final h=await AuthService.instance.hasUsers(); if(mounted)setState(()=>hasUsers=h); }
  @override Widget build(BuildContext context){
    if(hasUsers==null)return MaterialApp(theme:CardasTheme.light,home:const Scaffold(body:Center(child:CircularProgressIndicator())));
    return MaterialApp(title:'CARDAS',debugShowCheckedModeBanner:false,theme:CardasTheme.light,initialRoute:hasUsers!?'/login':'/first-run',routes:{
      '/first-run':(_)=>const FirstRunScreen(),'/login':(_)=>const LoginScreen(),'/':(_)=>const DashboardScreen(),'/incidents':(_)=>const IncidentListScreen(),'/incident/new':(_)=>const IncidentFormScreen(),'/incident/detail':(_)=>const IncidentDetailScreen(),'/household/new':(_)=>const HouseholdFormScreen(),'/warehouse':(_)=>const WarehouseScreen(),'/incident-map':(_)=>const IncidentMapScreen(),'/reports':(_)=>const ReportsScreen(),'/admin':(_)=>const AdminScreen(),'/users':(_)=>const UserManagementScreen(),'/sync':(_)=>const SyncScreen(),'/atlas':(_)=>const AtlasScreen(),'/operations':(_)=>const OperationsScreen(),
    });
  }
}
