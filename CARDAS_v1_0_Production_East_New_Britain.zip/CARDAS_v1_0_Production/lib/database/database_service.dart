import 'dart:convert';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import '../models/incident.dart';
import '../models/household.dart';
import '../models/warehouse_item.dart';
import '../models/incident_photo.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;

  Future<void> initialize() async {
    if (_db != null) return;
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(dir.path, 'cardas.db');
    _db = await openDatabase(dbPath, version: 4, onCreate: _onCreate, onUpgrade: _onUpgrade);
  }

  Database get db {
    final value = _db;
    if (value == null) throw StateError('DatabaseService.initialize() was not called.');
    return value;
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('CREATE TABLE districts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,code TEXT NOT NULL UNIQUE)');
    await db.execute('CREATE TABLE parishes(id INTEGER PRIMARY KEY AUTOINCREMENT,district_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT NOT NULL UNIQUE,FOREIGN KEY(district_id) REFERENCES districts(id))');
    await db.execute('CREATE TABLE villages(id INTEGER PRIMARY KEY AUTOINCREMENT,parish_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT NOT NULL UNIQUE,FOREIGN KEY(parish_id) REFERENCES parishes(id))');
    await db.execute('CREATE TABLE incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_code TEXT NOT NULL UNIQUE,district TEXT NOT NULL,parish TEXT NOT NULL,village TEXT NOT NULL,hazard TEXT NOT NULL,priority TEXT NOT NULL,latitude REAL,longitude REAL,description TEXT NOT NULL,created_at TEXT NOT NULL)');
    await db.execute('CREATE TABLE incident_photos(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_code TEXT NOT NULL,file_path TEXT NOT NULL,captured_at TEXT NOT NULL,latitude REAL,longitude REAL,FOREIGN KEY(incident_code) REFERENCES incidents(incident_code))');
    await db.execute('CREATE TABLE households(id INTEGER PRIMARY KEY AUTOINCREMENT,beneficiary_id TEXT NOT NULL UNIQUE,family_head TEXT NOT NULL,family_size INTEGER NOT NULL,district TEXT NOT NULL,parish TEXT NOT NULL,village TEXT NOT NULL,immediate_needs TEXT NOT NULL,created_at TEXT NOT NULL)');
    await db.execute('CREATE TABLE warehouse_items(id INTEGER PRIMARY KEY AUTOINCREMENT,item_name TEXT NOT NULL,category TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 0,unit TEXT NOT NULL)');
    await db.execute('CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL UNIQUE,display_name TEXT NOT NULL,role TEXT NOT NULL,password_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)');
    await db.execute('CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL,created_at TEXT NOT NULL)');
    await db.execute('CREATE TABLE sync_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,operation TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL,synced INTEGER NOT NULL DEFAULT 0)');
    await _createOperationalTables(db);
    await _seed(db);
  }

  Future<void> _createOperationalTables(Database db) async {
    await db.execute('CREATE TABLE distributions(id INTEGER PRIMARY KEY AUTOINCREMENT,beneficiary_id TEXT NOT NULL,item_id INTEGER NOT NULL,quantity INTEGER NOT NULL,issued_by TEXT NOT NULL,issued_at TEXT NOT NULL,incident_code TEXT,notes TEXT)');
    await db.execute('CREATE TABLE volunteers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,parish TEXT,skills TEXT NOT NULL,availability TEXT NOT NULL DEFAULT 'Available',incident_code TEXT,created_at TEXT NOT NULL)');
    await db.execute('CREATE TABLE shelters(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,parish TEXT NOT NULL,village TEXT,capacity INTEGER NOT NULL DEFAULT 0,water_available INTEGER NOT NULL DEFAULT 0,toilets_available INTEGER NOT NULL DEFAULT 0,kitchen_available INTEGER NOT NULL DEFAULT 0,generator_available INTEGER NOT NULL DEFAULT 0,latitude REAL,longitude REAL,notes TEXT)');
    await db.execute('CREATE TABLE water_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,parish TEXT NOT NULL,village TEXT,source_type TEXT NOT NULL,status TEXT NOT NULL,latitude REAL,longitude REAL,notes TEXT)');
    await db.execute('CREATE TABLE recovery_projects(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_code TEXT NOT NULL,name TEXT NOT NULL,category TEXT NOT NULL,status TEXT NOT NULL,owner TEXT,started_at TEXT,completed_at TEXT,notes TEXT)');
    await db.execute('CREATE TABLE preparedness(id INTEGER PRIMARY KEY AUTOINCREMENT,parish TEXT NOT NULL UNIQUE,committee_established INTEGER NOT NULL DEFAULT 0,volunteers_trained INTEGER NOT NULL DEFAULT 0,shelter_inspected INTEGER NOT NULL DEFAULT 0,water_operational INTEGER NOT NULL DEFAULT 0,first_aid_available INTEGER NOT NULL DEFAULT 0,food_stock_available INTEGER NOT NULL DEFAULT 0,contacts_updated INTEGER NOT NULL DEFAULT 0,evacuation_plan_available INTEGER NOT NULL DEFAULT 0,assessed_at TEXT)');
    await db.execute('CREATE TABLE resource_inventory(id INTEGER PRIMARY KEY AUTOINCREMENT,parish TEXT NOT NULL,resource_type TEXT NOT NULL,name TEXT NOT NULL,quantity INTEGER NOT NULL DEFAULT 1,condition TEXT,latitude REAL,longitude REAL,notes TEXT)');
    await db.execute('CREATE TABLE atlas_places(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,type TEXT NOT NULL,district TEXT,parish TEXT,village TEXT,latitude REAL,longitude REAL,source TEXT,verified INTEGER NOT NULL DEFAULT 0,notes TEXT)');
    await db.execute('CREATE TABLE emergency_contacts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,service TEXT NOT NULL,phone TEXT,address TEXT,parish TEXT,district TEXT,notes TEXT)');
    await db.execute('CREATE TABLE disaster_timeline(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_code TEXT NOT NULL,event_type TEXT NOT NULL,event_at TEXT NOT NULL,notes TEXT,username TEXT NOT NULL)');
  }

  Future<void> _seed(Database db) async {
    final districts = [['Rabaul','RAB'],['Kokopo','KOK'],['Gazelle','GAZ'],['Pomio','POM']];
    for (final row in districts) await db.insert('districts', {'name':row[0],'code':row[1]});
    final ids = <String,int>{};
    for (final row in districts) ids[row[1]]=(await db.query('districts',where:'code=?',whereArgs:[row[1]])).first['id'] as int;
    final parishes = [[ids['RAB']!,'Vunapope','RAB-VUN'],[ids['RAB']!,'Raluana','RAB-RAL'],[ids['KOK']!,'Kokopo','KOK-KOK'],[ids['KOK']!,'Takubar','KOK-TAK'],[ids['GAZ']!,'Kerevat','GAZ-KER'],[ids['GAZ']!,'Toma','GAZ-TOM'],[ids['POM']!,'Pomio','POM-POM'],[ids['POM']!,'Palmalmal','POM-PAL']];
    for (final row in parishes) await db.insert('parishes', {'district_id':row[0],'name':row[1],'code':row[2]});
    final items = [['Rice','Food',0,'bag'],['Tarpaulin','Shelter',0,'piece'],['Hygiene Kit','WASH',0,'kit'],['Blanket','Shelter',0,'piece']];
    for (final row in items) await db.insert('warehouse_items', {'item_name':row[0],'category':row[1],'quantity':row[2],'unit':row[3]});
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) await db.execute('CREATE TABLE incident_photos(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_code TEXT NOT NULL,file_path TEXT NOT NULL,captured_at TEXT NOT NULL,latitude REAL,longitude REAL,FOREIGN KEY(incident_code) REFERENCES incidents(incident_code))');
    if (oldVersion < 3) {
      await db.execute('CREATE TABLE villages(id INTEGER PRIMARY KEY AUTOINCREMENT,parish_id INTEGER NOT NULL,name TEXT NOT NULL,code TEXT NOT NULL UNIQUE,FOREIGN KEY(parish_id) REFERENCES parishes(id))');
      await db.execute('CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL UNIQUE,display_name TEXT NOT NULL,role TEXT NOT NULL,password_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL,created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE sync_queue(id INTEGER PRIMARY KEY AUTOINCREMENT,entity_type TEXT NOT NULL,entity_id TEXT NOT NULL,operation TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL,synced INTEGER NOT NULL DEFAULT 0)');
    }
    if (oldVersion < 4) await _createOperationalTables(db);
  }

  Future<int> insertIncident(Incident item) async { final id=await db.insert('incidents', item.toMap()); await queueSync('incident',item.incidentCode,'create',item.toMap()); return id; }
  Future<List<Incident>> getIncidents() async => (await db.query('incidents',orderBy:'created_at DESC')).map(Incident.fromMap).toList();

  Future<void> saveIncidentWithPhotos(Incident item,List<XFile> sourcePhotos,Position? position) async {
    await db.transaction((txn) async {
      await txn.insert('incidents',item.toMap());
      if(sourcePhotos.isEmpty)return;
      final root=await getApplicationDocumentsDirectory(); final folder=Directory(p.join(root.path,'cardas_photos',item.incidentCode)); await folder.create(recursive:true);
      for(var i=0;i<sourcePhotos.length;i++){
        final source=File(sourcePhotos[i].path); final extension=p.extension(source.path).isEmpty?'.jpg':p.extension(source.path); final destination=File(p.join(folder.path,'photo_${i+1}$extension')); await source.copy(destination.path);
        await txn.insert('incident_photos',IncidentPhoto(incidentCode:item.incidentCode,filePath:destination.path,capturedAt:DateTime.now(),latitude:position?.latitude,longitude:position?.longitude).toMap());
      }
    });
    await queueSync('incident',item.incidentCode,'create',item.toMap());
  }
  Future<List<IncidentPhoto>> getIncidentPhotos(String incidentCode) async => (await db.query('incident_photos',where:'incident_code=?',whereArgs:[incidentCode],orderBy:'id')).map(IncidentPhoto.fromMap).toList();
  Future<int> insertHousehold(Household item) async { final id=await db.insert('households',item.toMap()); await queueSync('household',item.beneficiaryId,'create',item.toMap()); return id; }
  Future<List<Household>> getHouseholds() async => (await db.query('households',orderBy:'created_at DESC')).map(Household.fromMap).toList();
  Future<Map<String,int>> incidentCountsByHazard() async { final rows=await db.rawQuery('SELECT hazard,COUNT(*) AS count FROM incidents GROUP BY hazard ORDER BY count DESC'); return {for(final r in rows) r['hazard'] as String:(r['count'] as num).toInt()}; }
  Future<Map<String,int>> incidentCountsByPriority() async { final rows=await db.rawQuery('SELECT priority,COUNT(*) AS count FROM incidents GROUP BY priority ORDER BY count DESC'); return {for(final r in rows) r['priority'] as String:(r['count'] as num).toInt()}; }
  Future<List<WarehouseItem>> getWarehouse() async => (await db.query('warehouse_items',orderBy:'item_name')).map(WarehouseItem.fromMap).toList();
  Future<int> updateWarehouseQuantity(int id,int quantity) async { final n=await db.update('warehouse_items',{'quantity':quantity},where:'id=?',whereArgs:[id]); await queueSync('warehouse',id.toString(),'update',{'id':id,'quantity':quantity}); return n; }
  Future<int> incidentCount() async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM incidents'))??0;
  Future<int> householdCount() async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM households'))??0;
  Future<int> warehouseUnits() async => Sqflite.firstIntValue(await db.rawQuery('SELECT COALESCE(SUM(quantity),0) FROM warehouse_items'))??0;

  Future<bool> hasUsers() async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM app_users')) != 0;
  Future<Map<String,dynamic>?> findUser(String username) async { final rows=await db.query('app_users',where:'username=?',whereArgs:[username],limit:1); return rows.isEmpty?null:rows.first; }
  Future<int> createUser({required String username,required String displayName,required String role,required String passwordHash}) async => db.insert('app_users',{'username':username,'display_name':displayName,'role':role,'password_hash':passwordHash,'active':1,'created_at':DateTime.now().toIso8601String()});
  Future<List<Map<String,dynamic>>> getUsers() => db.query('app_users',orderBy:'display_name');
  Future<void> logAudit(String username,String action,String details) => db.insert('audit_log',{'username':username,'action':action,'details':details,'created_at':DateTime.now().toIso8601String()});

  Future<List<Map<String,dynamic>>> getDistricts() => db.query('districts',orderBy:'name');
  Future<List<Map<String,dynamic>>> getParishes() => db.rawQuery('SELECT parishes.*, districts.name AS district_name FROM parishes JOIN districts ON districts.id=parishes.district_id ORDER BY parishes.name');
  Future<List<Map<String,dynamic>>> getVillages() => db.rawQuery('SELECT villages.*, parishes.name AS parish_name FROM villages JOIN parishes ON parishes.id=villages.parish_id ORDER BY villages.name');
  Future<int> addDistrict(String name,String code) => db.insert('districts',{'name':name,'code':code});
  Future<int> addParish(int districtId,String name,String code) => db.insert('parishes',{'district_id':districtId,'name':name,'code':code});
  Future<int> addVillage(int parishId,String name,String code) => db.insert('villages',{'parish_id':parishId,'name':name,'code':code});

  Future<void> queueSync(String entityType,String entityId,String operation,Map<String,dynamic> payload) async => db.insert('sync_queue',{'entity_type':entityType,'entity_id':entityId,'operation':operation,'payload':jsonEncode(payload),'created_at':DateTime.now().toIso8601String(),'synced':0});
  Future<List<Map<String,dynamic>>> getPendingSync() => db.query('sync_queue',where:'synced=0',orderBy:'id');
  Future<void> markSyncAsSynced(int id) => db.update('sync_queue',{'synced':1},where:'id=?',whereArgs:[id]);

  Future<Map<String,dynamic>> exportAllData() async {
    const tables=['districts','parishes','villages','incidents','incident_photos','households','warehouse_items','audit_log','sync_queue'];
    final result=<String,dynamic>{'format':'CARDAS_BACKUP_V1','created_at':DateTime.now().toIso8601String(),'tables':{}};
    for(final table in tables) result['tables'][table]=await db.query(table);
    return result;
  }

  Future<void> restoreAllData(Map<String,dynamic> backup) async {
    final tables=backup['tables']; if(tables is! Map) throw const FormatException('Backup tables are missing.');
    const order=['sync_queue','audit_log','incident_photos','incidents','households','warehouse_items','villages','parishes','districts'];
    await db.transaction((txn) async {
      for(final table in order) await txn.delete(table);
      const insertOrder=['districts','parishes','villages','incidents','incident_photos','households','warehouse_items','audit_log','sync_queue'];
      for(final table in insertOrder){ final rows=tables[table]; if(rows is! List)continue; for(final row in rows){ if(row is Map) await txn.insert(table,Map<String,dynamic>.from(row),conflictAlgorithm:ConflictAlgorithm.replace); } }
    });
  }

  Future<List<Map<String,dynamic>>> getAtlasPlaces() => db.query('atlas_places',orderBy:'type,name');
  Future<int> addAtlasPlace(Map<String,dynamic> data) => db.insert('atlas_places',data);
  Future<List<Map<String,dynamic>>> getDistributions() => db.rawQuery('SELECT distributions.*, warehouse_items.item_name FROM distributions JOIN warehouse_items ON warehouse_items.id=distributions.item_id ORDER BY issued_at DESC');
  Future<int> addDistribution({required String beneficiaryId, required int itemId, required int quantity, required String issuedBy, String? incidentCode, String? notes}) async { return db.transaction((txn) async { final rows=await txn.query('warehouse_items',where:'id=?',whereArgs:[itemId],limit:1); if(rows.isEmpty) throw StateError('Warehouse item not found'); final stock=(rows.first['quantity'] as int); if(quantity<=0 || quantity>stock) throw StateError('Insufficient stock'); await txn.update('warehouse_items',{'quantity':stock-quantity},where:'id=?',whereArgs:[itemId]); return txn.insert('distributions',{'beneficiary_id':beneficiaryId,'item_id':itemId,'quantity':quantity,'issued_by':issuedBy,'issued_at':DateTime.now().toIso8601String(),'incident_code':incidentCode,'notes':notes}); }); }
  Future<List<Map<String,dynamic>>> getVolunteers() => db.query('volunteers',orderBy:'name');
  Future<int> addVolunteer(Map<String,dynamic> data) => db.insert('volunteers',{...data,'created_at':DateTime.now().toIso8601String()});
  Future<List<Map<String,dynamic>>> getShelters() => db.query('shelters',orderBy:'name');
  Future<int> addShelter(Map<String,dynamic> data) => db.insert('shelters',data);
  Future<List<Map<String,dynamic>>> getWaterSources() => db.query('water_sources',orderBy:'name');
  Future<int> addWaterSource(Map<String,dynamic> data) => db.insert('water_sources',data);
  Future<List<Map<String,dynamic>>> getRecoveryProjects() => db.query('recovery_projects',orderBy:'id DESC');
  Future<int> addRecoveryProject(Map<String,dynamic> data) => db.insert('recovery_projects',data);
  Future<List<Map<String,dynamic>>> getPreparedness() => db.query('preparedness',orderBy:'parish');
  Future<int> upsertPreparedness(Map<String,dynamic> data) => db.insert('preparedness',data,conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<Map<String,dynamic>>> getResources() => db.query('resource_inventory',orderBy:'parish,name');
  Future<int> addResource(Map<String,dynamic> data) => db.insert('resource_inventory',data);
  Future<List<Map<String,dynamic>>> getContacts() => db.query('emergency_contacts',orderBy:'service,name');
  Future<int> addContact(Map<String,dynamic> data) => db.insert('emergency_contacts',data);
  Future<List<Map<String,dynamic>>> getTimeline(String incidentCode) => db.query('disaster_timeline',where:'incident_code=?',whereArgs:[incidentCode],orderBy:'event_at');
  Future<int> addTimeline(String incidentCode,String eventType,String notes,String username) => db.insert('disaster_timeline',{'incident_code':incidentCode,'event_type':eventType,'event_at':DateTime.now().toIso8601String(),'notes':notes,'username':username});
}
