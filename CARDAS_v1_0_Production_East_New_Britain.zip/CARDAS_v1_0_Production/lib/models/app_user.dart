class AppUser {
  final int? id;
  final String username;
  final String displayName;
  final String role;
  final String passwordHash;
  final bool active;
  final DateTime createdAt;

  AppUser({this.id, required this.username, required this.displayName, required this.role, required this.passwordHash, this.active = true, required this.createdAt});

  factory AppUser.fromMap(Map<String, dynamic> m) => AppUser(
    id: m['id'] as int?, username: m['username'] as String, displayName: m['display_name'] as String,
    role: m['role'] as String, passwordHash: m['password_hash'] as String,
    active: (m['active'] as int? ?? 1) == 1, createdAt: DateTime.parse(m['created_at'] as String),
  );
}
