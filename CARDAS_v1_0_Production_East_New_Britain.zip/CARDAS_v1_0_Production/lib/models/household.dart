class Household {
  final int? id;
  final String beneficiaryId;
  final String familyHead;
  final int familySize;
  final String district;
  final String parish;
  final String village;
  final String immediateNeeds;
  final DateTime createdAt;

  const Household({
    this.id,
    required this.beneficiaryId,
    required this.familyHead,
    required this.familySize,
    required this.district,
    required this.parish,
    required this.village,
    required this.immediateNeeds,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'beneficiary_id': beneficiaryId,
        'family_head': familyHead,
        'family_size': familySize,
        'district': district,
        'parish': parish,
        'village': village,
        'immediate_needs': immediateNeeds,
        'created_at': createdAt.toIso8601String(),
      };
}
