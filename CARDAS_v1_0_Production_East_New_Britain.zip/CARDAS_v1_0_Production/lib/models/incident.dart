class Incident {
  final int? id;
  final String incidentCode;
  final String district;
  final String parish;
  final String village;
  final String hazard;
  final String priority;
  final double? latitude;
  final double? longitude;
  final String description;
  final DateTime createdAt;

  const Incident({
    this.id,
    required this.incidentCode,
    required this.district,
    required this.parish,
    required this.village,
    required this.hazard,
    required this.priority,
    this.latitude,
    this.longitude,
    required this.description,
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'incident_code': incidentCode,
        'district': district,
        'parish': parish,
        'village': village,
        'hazard': hazard,
        'priority': priority,
        'latitude': latitude,
        'longitude': longitude,
        'description': description,
        'created_at': createdAt.toIso8601String(),
      };

  factory Incident.fromMap(Map<String, Object?> m) => Incident(
        id: m['id'] as int?,
        incidentCode: m['incident_code'] as String,
        district: m['district'] as String,
        parish: m['parish'] as String,
        village: m['village'] as String,
        hazard: m['hazard'] as String,
        priority: m['priority'] as String,
        latitude: (m['latitude'] as num?)?.toDouble(),
        longitude: (m['longitude'] as num?)?.toDouble(),
        description: (m['description'] as String?) ?? '',
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}
