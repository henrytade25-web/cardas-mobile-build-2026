class IncidentPhoto {
  final int? id;
  final String incidentCode;
  final String filePath;
  final DateTime capturedAt;
  final double? latitude;
  final double? longitude;

  const IncidentPhoto({
    this.id,
    required this.incidentCode,
    required this.filePath,
    required this.capturedAt,
    this.latitude,
    this.longitude,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'incident_code': incidentCode,
        'file_path': filePath,
        'captured_at': capturedAt.toIso8601String(),
        'latitude': latitude,
        'longitude': longitude,
      };

  factory IncidentPhoto.fromMap(Map<String, Object?> map) => IncidentPhoto(
        id: map['id'] as int?,
        incidentCode: map['incident_code'] as String,
        filePath: map['file_path'] as String,
        capturedAt: DateTime.parse(map['captured_at'] as String),
        latitude: (map['latitude'] as num?)?.toDouble(),
        longitude: (map['longitude'] as num?)?.toDouble(),
      );
}
