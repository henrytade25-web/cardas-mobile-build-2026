class Parish {
  final int? id;
  final int districtId;
  final String name;
  final String code;

  const Parish({this.id, required this.districtId, required this.name, required this.code});

  Map<String, Object?> toMap() => {
        'id': id,
        'district_id': districtId,
        'name': name,
        'code': code,
      };
}
