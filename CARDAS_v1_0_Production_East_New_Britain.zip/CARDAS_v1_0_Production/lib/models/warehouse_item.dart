class WarehouseItem {
  final int? id;
  final String itemName;
  final String category;
  final int quantity;
  final String unit;

  const WarehouseItem({
    this.id,
    required this.itemName,
    required this.category,
    required this.quantity,
    required this.unit,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'item_name': itemName,
        'category': category,
        'quantity': quantity,
        'unit': unit,
      };

  factory WarehouseItem.fromMap(Map<String, Object?> m) => WarehouseItem(
        id: m['id'] as int?,
        itemName: m['item_name'] as String,
        category: m['category'] as String,
        quantity: m['quantity'] as int,
        unit: m['unit'] as String,
      );
}
