import 'package:flutter/material.dart';
import '../database/database_service.dart';
import '../services/auth_service.dart';
import '../services/backup_service.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override State<AdminScreen> createState() => _AdminScreenState();
}
class _AdminScreenState extends State<AdminScreen> {
  List<Map<String, dynamic>> districts = [], parishes = [], villages = [];
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final d = await DatabaseService.instance.getDistricts();
    final p = await DatabaseService.instance.getParishes();
    final v = await DatabaseService.instance.getVillages();
    if (mounted) setState(() { districts = d; parishes = p; villages = v; });
  }
  Future<void> _add(String type) async {
    final name = TextEditingController(); final code = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: Text('Add $type'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')), TextField(controller: code, decoration: const InputDecoration(labelText: 'Code (unique)'))]), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save'))]));
    if (ok != true || name.text.trim().isEmpty || code.text.trim().isEmpty) return;
    try {
      if (type == 'District') await DatabaseService.instance.addDistrict(name.text.trim(), code.text.trim());
      if (type == 'Parish') { final districtId = districts.isEmpty ? null : await _pickId('district'); if (districtId != null) await DatabaseService.instance.addParish(districtId, name.text.trim(), code.text.trim()); }
      if (type == 'Village') { final parishId = parishes.isEmpty ? null : await _pickId('parish'); if (parishId != null) await DatabaseService.instance.addVillage(parishId, name.text.trim(), code.text.trim()); }
      await _load();
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e'))); }
  }
  Future<int?> _pickId(String type) async {
    final items = type == 'district' ? districts : parishes;
    return showDialog<int>(context: context, builder: (_) => SimpleDialog(title: Text('Select $type'), children: [for (final x in items) SimpleDialogOption(onPressed: () => Navigator.pop(context, x['id'] as int), child: Text(x['name'] as String))]));
  }
  Future<void> _backup() async { final f = await BackupService.instance.createBackup(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup created: ${f.path}'))); }
  Future<void> _restore() async { try { final path = await BackupService.instance.pickAndRestoreBackup(); if (path != null && mounted) { await _load(); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup restored. Restart CARDAS if a screen still shows old data.'))); } } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore failed: $e'))); } }
  @override Widget build(BuildContext context) {
    if (AuthService.instance.currentUser?.role != 'admin') return const Scaffold(body: Center(child: Text('Administrator access required.')));
    return Scaffold(appBar: AppBar(title: const Text('Administration')), body: ListView(padding: const EdgeInsets.all(16), children: [
    Text('Signed in as ${AuthService.instance.currentUser?.displayName ?? ''} (${AuthService.instance.currentUser?.role ?? ''})'), const SizedBox(height: 16),
    const Text('Master data', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    _MasterCard('Districts', districts, () => _add('District')), _MasterCard('Parishes', parishes, () => _add('Parish')), _MasterCard('Villages', villages, () => _add('Village')),
    const SizedBox(height: 12), const Text('Data protection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    ListTile(leading: const Icon(Icons.backup), title: const Text('Create backup'), subtitle: const Text('Exports operational data to a JSON backup file.'), onTap: _backup),
    ListTile(leading: const Icon(Icons.restore), title: const Text('Restore backup'), subtitle: const Text('Replaces local operational data with a CARDAS backup.'), onTap: _restore),
  ]));
  }
}
class _MasterCard extends StatelessWidget { final String title; final List<Map<String,dynamic>> items; final VoidCallback onAdd; const _MasterCard(this.title,this.items,this.onAdd); @override Widget build(BuildContext c)=>Card(child: ExpansionTile(title: Text('$title (${items.length})'), children: [for(final x in items.take(30)) ListTile(title: Text(x['name'] as String), subtitle: Text(x['code'] as String)), ListTile(leading: const Icon(Icons.add), title: Text('Add $title item'), onTap: onAdd)])); }
