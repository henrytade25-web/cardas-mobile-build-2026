import 'package:flutter/material.dart';
import '../database/database_service.dart';
import '../theme/cardas_theme.dart';
import '../services/auth_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  int incidents = 0, households = 0, stock = 0;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final db = DatabaseService.instance;
    final i = await db.incidentCount();
    final h = await db.householdCount();
    final s = await db.warehouseUnits();
    if (mounted) {
      setState(() {
        incidents = i;
        households = h;
        stock = s;
      });
    }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('CARDAS Dashboard')),
    drawer: Drawer(child: ListView(children: [
      DrawerHeader(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(height: 60, child: Image.asset('assets/branding/caritas_rabaul_logo.jpg', fit: BoxFit.contain)),
        const Text('Caritas Rabaul Office', style: TextStyle(fontWeight: FontWeight.bold)),
      ])),
      ListTile(leading: const Icon(Icons.warning_amber), title: const Text('Incidents'), onTap: () => Navigator.pushNamed(context, '/incidents')),
      ListTile(leading: const Icon(Icons.inventory_2), title: const Text('Warehouse'), onTap: () => Navigator.pushNamed(context, '/warehouse')),
      ListTile(leading: const Icon(Icons.family_restroom), title: const Text('Register Household'), onTap: () => Navigator.pushNamed(context, '/household/new')),
      ListTile(leading: const Icon(Icons.assessment), title: const Text('Reports & Export'), onTap: () => Navigator.pushNamed(context, '/reports')),
      ListTile(leading: const Icon(Icons.map), title: const Text('Incident Map'), onTap: () => Navigator.pushNamed(context, '/incident-map')),
      ListTile(leading: const Icon(Icons.sync), title: const Text('Synchronization'), onTap: () => Navigator.pushNamed(context, '/sync')),
      if (AuthService.instance.currentUser?.role == 'admin') ...[
        ListTile(leading: const Icon(Icons.admin_panel_settings), title: const Text('Administration'), onTap: () => Navigator.pushNamed(context, '/admin')),
        ListTile(leading: const Icon(Icons.manage_accounts), title: const Text('User Management'), onTap: () => Navigator.pushNamed(context, '/users')),
      ],
      const Divider(),
      ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: () async { await AuthService.instance.logout(); if (context.mounted) Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false); }),
    ])),
    body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Image.asset('assets/branding/caritas_rabaul_logo.jpg', height: 100)),
        const SizedBox(width: 12),
        Expanded(child: Image.asset('assets/branding/archdiocese_rabaul_crest.png', height: 100)),
      ]),
      const SizedBox(height: 20),
      Text('Signed in: ${AuthService.instance.currentUser?.displayName ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      const Text('Disaster Assessment & Response', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      Wrap(spacing: 12, runSpacing: 12, children: [
        _Card('Incidents', incidents, Icons.warning),
        _Card('Households', households, Icons.groups),
        _Card('Stock Units', stock, Icons.inventory),
      ]),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: () => Navigator.pushNamed(context, '/incident/new').then((_) => _load()), icon: const Icon(Icons.add_alert), label: const Text('New Disaster Assessment')),
      OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, '/household/new').then((_) => _load()), icon: const Icon(Icons.person_add), label: const Text('Register Household')),
      OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, '/reports'), icon: const Icon(Icons.assessment), label: const Text('Reports & Export')),
      OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, '/incident-map'), icon: const Icon(Icons.map), label: const Text('Incident Map')), 
    ])),
  );
}
class _Card extends StatelessWidget { final String label; final int value; final IconData icon; const _Card(this.label,this.value,this.icon); @override Widget build(BuildContext c)=>SizedBox(width: 170, child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Icon(icon,color: CardasTheme.caritasGreen),const SizedBox(height:8),Text('$value',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(label)])))); }
