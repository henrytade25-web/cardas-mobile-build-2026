import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class FirstRunScreen extends StatefulWidget {
  const FirstRunScreen({super.key});
  @override State<FirstRunScreen> createState() => _FirstRunScreenState();
}

class _FirstRunScreenState extends State<FirstRunScreen> {
  final name = TextEditingController(text: 'CARDAS Administrator');
  final username = TextEditingController(text: 'admin');
  final password = TextEditingController();
  final confirm = TextEditingController();
  String? error;
  bool busy = false;

  Future<void> _create() async {
    if (username.text.trim().isEmpty || name.text.trim().isEmpty) { setState(() => error = 'Name and username are required.'); return; }
    if (password.text.length < 8) { setState(() => error = 'Use a password of at least 8 characters.'); return; }
    if (password.text != confirm.text) { setState(() => error = 'Passwords do not match.'); return; }
    setState(() { busy = true; error = null; });
    try {
      await AuthService.instance.createUser(username: username.text, displayName: name.text, role: 'admin', password: password.text);
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
    } catch (e) {
      if (mounted) setState(() => error = 'Could not create administrator: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 520),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/branding/caritas_rabaul_logo.jpg', height: 80),
                  const SizedBox(height: 12),
                  const Text('First-time setup', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Create the first CARDAS administrator account. Keep the password secure.'),
                  const SizedBox(height: 20),
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name')),
                  TextField(controller: username, decoration: const InputDecoration(labelText: 'Username')),
                  TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
                  TextField(controller: confirm, obscureText: true, decoration: const InputDecoration(labelText: 'Confirm password')),
                  if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                  const SizedBox(height: 20),
                  SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : _create, child: Text(busy ? 'Creating…' : 'Create administrator'))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
