import 'dart:io';

import 'package:flutter/material.dart';

import '../database/database_service.dart';
import '../models/incident.dart';
import '../models/incident_photo.dart';

class IncidentDetailScreen extends StatefulWidget {
  final Incident incident;
  const IncidentDetailScreen({super.key, required this.incident});

  @override
  State<IncidentDetailScreen> createState() => _IncidentDetailScreenState();
}

class _IncidentDetailScreenState extends State<IncidentDetailScreen> {
  List<IncidentPhoto> photos = [];

  @override
  void initState() {
    super.initState();
    loadPhotos();
  }

  Future<void> loadPhotos() async {
    final result = await DatabaseService.instance.getIncidentPhotos(widget.incident.incidentCode);
    if (mounted) setState(() => photos = result);
  }

  @override
  Widget build(BuildContext context) {
    final x = widget.incident;
    return Scaffold(
      appBar: AppBar(title: Text(x.incidentCode)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('${x.hazard} — ${x.priority}', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text('${x.district} / ${x.parish} / ${x.village}'),
          const SizedBox(height: 16),
          Text(x.description),
          const SizedBox(height: 16),
          if (x.latitude != null && x.longitude != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.location_on),
                title: const Text('GPS coordinates'),
                subtitle: Text('${x.latitude!.toStringAsFixed(6)}, ${x.longitude!.toStringAsFixed(6)}'),
              ),
            ),
          const SizedBox(height: 12),
          Text('Incident photos (${photos.length})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (photos.isEmpty)
            const Text('No photos attached.')
          else
            ...photos.map(
              (photo) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.file(File(photo.filePath), fit: BoxFit.cover),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
