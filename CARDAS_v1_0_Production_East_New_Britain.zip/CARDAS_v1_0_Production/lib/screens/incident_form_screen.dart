import 'dart:io';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

import '../database/database_service.dart';
import '../models/incident.dart';

class IncidentFormScreen extends StatefulWidget {
  const IncidentFormScreen({super.key});

  @override
  State<IncidentFormScreen> createState() => _IncidentFormScreenState();
}

class _IncidentFormScreenState extends State<IncidentFormScreen> {
  final form = GlobalKey<FormState>();
  final district = TextEditingController(text: 'Rabaul');
  final parish = TextEditingController(text: 'Vunapope');
  final village = TextEditingController();
  final description = TextEditingController();
  final picker = ImagePicker();

  String hazard = 'Fire';
  String priority = 'High';
  Position? position;
  bool locating = false;
  bool saving = false;
  final List<XFile> photos = [];

  @override
  void dispose() {
    district.dispose();
    parish.dispose();
    village.dispose();
    description.dispose();
    super.dispose();
  }

  Future<void> captureLocation() async {
    setState(() => locating = true);
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) throw Exception('Location services are turned off.');

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('Location permission was not granted.');
      }

      final result = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (mounted) setState(() => position = result);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('GPS: ${e.toString().replaceFirst('Exception: ', '')}')),
        );
      }
    } finally {
      if (mounted) setState(() => locating = false);
    }
  }

  Future<void> addPhoto() async {
    if (photos.length >= 5) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Maximum of 5 photos per assessment.')),
      );
      return;
    }

    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take photo'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from device'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;

    try {
      final image = await picker.pickImage(
        source: source,
        imageQuality: 82,
        maxWidth: 1920,
      );
      if (image != null && mounted) setState(() => photos.add(image));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Photo: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      final now = DateTime.now();
      final code = 'INC-${now.year}-${now.microsecondsSinceEpoch.toString().substring(8)}';
      final incident = Incident(
        incidentCode: code,
        district: district.text.trim(),
        parish: parish.text.trim(),
        village: village.text.trim(),
        hazard: hazard,
        priority: priority,
        latitude: position?.latitude,
        longitude: position?.longitude,
        description: description.text.trim(),
        createdAt: now,
      );
      await DatabaseService.instance.saveIncidentWithPhotos(incident, photos, position);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save assessment: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Disaster Assessment')),
      body: Form(
        key: form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field('District', district),
            _field('Parish', parish),
            _field('Village', village),
            DropdownButtonFormField<String>(
              value: hazard,
              items: ['Fire', 'Flood', 'Earthquake', 'Volcanic Activity', 'Landslide', 'Drought', 'Storm/Cyclone', 'Other']
                  .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                  .toList(),
              onChanged: (x) => setState(() => hazard = x!),
              decoration: const InputDecoration(labelText: 'Hazard Type'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: priority,
              items: ['Low', 'Medium', 'High', 'Critical']
                  .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                  .toList(),
              onChanged: (x) => setState(() => priority = x!),
              decoration: const InputDecoration(labelText: 'Priority'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: description,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'Description'),
              validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('GPS location', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text(position == null
                        ? 'No coordinates captured yet.'
                        : 'Latitude ${position!.latitude.toStringAsFixed(6)}\nLongitude ${position!.longitude.toStringAsFixed(6)}'),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: locating ? null : captureLocation,
                      icon: locating
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.my_location),
                      label: Text(locating ? 'Getting location…' : 'Capture current location'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Incident photos', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('${photos.length}/5'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (photos.isNotEmpty)
                      SizedBox(
                        height: 96,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: photos.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, i) => Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.file(File(photos[i].path), width: 96, height: 96, fit: BoxFit.cover),
                              ),
                              Positioned(
                                right: 2,
                                top: 2,
                                child: IconButton.filledTonal(
                                  onPressed: () => setState(() => photos.removeAt(i)),
                                  icon: const Icon(Icons.close, size: 18),
                                  tooltip: 'Remove',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    OutlinedButton.icon(
                      onPressed: addPhoto,
                      icon: const Icon(Icons.add_a_photo),
                      label: const Text('Add photo'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: saving ? null : save,
              icon: saving
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.save),
              label: Text(saving ? 'Saving…' : 'Save Assessment'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctl) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: ctl,
          decoration: InputDecoration(labelText: label),
          validator: (v) => v == null || v.trim().isEmpty ? 'Required' : null,
        ),
      );
}
