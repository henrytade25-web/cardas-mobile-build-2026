import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../database/database_service.dart';
import '../models/incident.dart';

class IncidentMapScreen extends StatefulWidget {
  const IncidentMapScreen({super.key});

  @override
  State<IncidentMapScreen> createState() => _IncidentMapScreenState();
}

class _IncidentMapScreenState extends State<IncidentMapScreen> {
  List<Incident> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final all = await DatabaseService.instance.getIncidents();
    if (mounted) {
      setState(() => items = all.where((x) => x.latitude != null && x.longitude != null).toList());
    }
  }

  LatLng get center {
    if (items.isEmpty) return const LatLng(-4.205, 152.174);
    return LatLng(items.first.latitude!, items.first.longitude!);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Incident Map'),
          bottom: const TabBar(tabs: [
            Tab(icon: Icon(Icons.map), text: 'Map'),
            Tab(icon: Icon(Icons.offline_bolt), text: 'Offline Data'),
          ]),
        ),
        body: TabBarView(children: [_onlineMap(context), _offlineData(context)]),
      ),
    );
  }

  Widget _onlineMap(BuildContext context) {
    if (items.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('No incidents with GPS coordinates are stored yet.'),
        ),
      );
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: const Text('Map background uses OpenStreetMap when internet is available. Incident data itself is stored locally.'),
        ),
        Expanded(
          child: FlutterMap(
            options: MapOptions(initialCenter: center, initialZoom: 9),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'org.caritasrabaul.cardas',
              ),
              MarkerLayer(
                markers: [
                  for (final x in items)
                    Marker(
                      point: LatLng(x.latitude!, x.longitude!),
                      width: 52,
                      height: 52,
                      child: Tooltip(
                        message: '${x.hazard} — ${x.priority}\n${x.incidentCode}',
                        child: const Icon(Icons.location_on, size: 42),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _offlineData(BuildContext context) {
    if (items.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('No GPS-tagged incident data is stored yet. Capture a location when creating an assessment.'),
        ),
      );
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: const Text(
            'This tab is fully offline: coordinates come from the local CARDAS database. No map tiles are downloaded or required.',
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final x = items[i];
              return Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('${i + 1}')),
                  title: Text('${x.hazard} — ${x.priority}'),
                  subtitle: Text('${x.incidentCode}\n${x.latitude!.toStringAsFixed(6)}, ${x.longitude!.toStringAsFixed(6)}\n${x.district} / ${x.parish} / ${x.village}'),
                  isThreeLine: true,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
