import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String? error;

  Future<void> _login() async {
    setState(() { busy = true; error = null; });
    final ok = await AuthService.instance.login(username.text, password.text);
    if (!mounted) return;
    setState(() => busy = false);
    if (ok) {
      Navigator.pushReplacementNamed(context, '/');
    } else {
      setState(() => error = 'Invalid username or password.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Card(
            margin: const EdgeInsets.all(24),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('assets/branding/caritas_rabaul_logo.jpg', height: 90),
                  const SizedBox(height: 10),
                  Image.asset('assets/branding/archdiocese_rabaul_crest.png', height: 80),
                  const SizedBox(height: 16),
                  const Text('CARDAS', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  const Text('Caritas Rabaul Disaster Assessment System'),
                  const SizedBox(height: 24),
                  TextField(controller: username, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person))),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock))),
                  if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                  const SizedBox(height: 20),
                  SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : _login, child: Text(busy ? 'Signing in…' : 'Sign in'))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
