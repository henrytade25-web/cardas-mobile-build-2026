import 'package:flutter/material.dart';
import '../database/database_service.dart';
import '../services/report_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool busy = false;
  Map<String, int> hazards = {};
  Map<String, int> priorities = {};

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final db = DatabaseService.instance;
    final h = await db.incidentCountsByHazard();
    final p = await db.incidentCountsByPriority();
    if (mounted) setState(() { hazards = h; priorities = p; });
  }

  Future<void> _run(Future<String> Function() action) async {
    setState(() => busy = true);
    try {
      final path = await action();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export saved:\n$path')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export failed: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _sharePdf() async {
    setState(() => busy = true);
    try {
      await ReportService.instance.shareSituationReport();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sharing failed: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reports & Export')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Situation Report', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Generate a report from the data currently stored on this device.'),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: busy ? null : _sharePdf,
              icon: const Icon(Icons.picture_as_pdf),
              label: const Text('Generate & Share PDF Situation Report'),
            ),
            OutlinedButton.icon(
              onPressed: busy ? null : () => _run(ReportService.instance.saveSituationReport),
              icon: const Icon(Icons.save_alt),
              label: const Text('Save PDF to Device'),
            ),
            const SizedBox(height: 24),
            const Text('CSV Data Exports', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _exportButton('Incidents CSV', Icons.warning_amber, ReportService.instance.exportIncidentsCsv),
            _exportButton('Households CSV', Icons.groups, ReportService.instance.exportHouseholdsCsv),
            _exportButton('Warehouse CSV', Icons.inventory_2, ReportService.instance.exportWarehouseCsv),
            const SizedBox(height: 24),
            const Text('Incident Breakdown', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (hazards.isEmpty && priorities.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No incidents registered yet.'))),
            if (hazards.isNotEmpty) ...[
              const Text('By hazard'),
              ...hazards.entries.map((e) => ListTile(dense: true, title: Text(e.key), trailing: Text('${e.value}'))),
            ],
            if (priorities.isNotEmpty) ...[
              const Text('By priority'),
              ...priorities.entries.map((e) => ListTile(dense: true, title: Text(e.key), trailing: Text('${e.value}'))),
            ],
          ],
        ),
      ),
    );
  }

  Widget _exportButton(String label, IconData icon, Future<String> Function() action) =>
      ListTile(leading: Icon(icon), title: Text(label), trailing: const Icon(Icons.download),
        onTap: busy ? null : () => _run(action));
}
