import 'package:flutter/material.dart';
import '../services/sync_service.dart';
import '../database/database_service.dart';

class SyncScreen extends StatefulWidget { const SyncScreen({super.key}); @override State<SyncScreen> createState()=>_SyncScreenState(); }
class _SyncScreenState extends State<SyncScreen> {
  String status='Checking…';
  @override void initState(){super.initState();_load();}
  Future<void> _load() async { final s=await SyncService.instance.statusMessage(); if(mounted)setState(()=>status=s); }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Synchronization')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:ListTile(leading:const Icon(Icons.sync),title:const Text('Local synchronization queue'),subtitle:Text(status))),
    const SizedBox(height:12),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Package G architecture',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('CARDAS records changes locally in a sync queue. This preserves offline operation and gives the future server connector a defined hand-off point. No field data is transmitted in this package. Before enabling network sync, define the server, authentication, encryption, conflict resolution, data ownership and retention rules.'),]))),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:_load,icon:const Icon(Icons.refresh),label:const Text('Refresh queue status')),
    FilledButton.icon(onPressed:() async { final rows=await DatabaseService.instance.getPendingSync(); if(context.mounted) showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Pending records'),content:Text('${rows.length} local record(s) are queued. They remain on this device until a sync connector is configured.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])); },icon:const Icon(Icons.list),label:const Text('View queue count')),
  ]));
}
