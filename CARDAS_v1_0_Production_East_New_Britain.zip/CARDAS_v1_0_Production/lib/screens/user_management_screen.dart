import 'package:flutter/material.dart';
import '../database/database_service.dart';
import '../services/auth_service.dart';

class UserManagementScreen extends StatefulWidget {
  const UserManagementScreen({super.key});
  @override State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  List<Map<String, dynamic>> users = [];
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { final x = await DatabaseService.instance.getUsers(); if (mounted) setState(() => users = x); }

  Future<void> _add() async {
    final u = TextEditingController(); final n = TextEditingController(); final p = TextEditingController();
    String role = 'assessor';
    final ok = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (c, setDialog) {
      return AlertDialog(
        title: const Text('Add user'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: u, decoration: const InputDecoration(labelText: 'Username')),
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Display name')),
          DropdownButtonFormField<String>(value: role, items: const [
            DropdownMenuItem(value: 'admin', child: Text('Administrator')),
            DropdownMenuItem(value: 'coordinator', child: Text('Coordinator')),
            DropdownMenuItem(value: 'assessor', child: Text('Assessor')),
            DropdownMenuItem(value: 'warehouse', child: Text('Warehouse')),
          ], onChanged: (v) => setDialog(() => role = v ?? 'assessor'), decoration: const InputDecoration(labelText: 'Role')),
          TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'Temporary password')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Create'))],
      );
    }));
    if (ok != true) return;
    if (u.text.trim().isEmpty || n.text.trim().isEmpty || p.text.length < 8) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Username, display name and an 8+ character password are required.'))); return; }
    try { await AuthService.instance.createUser(username: u.text, displayName: n.text, role: role, password: p.text); await _load(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'))); }
  }

  @override
  Widget build(BuildContext context) {
    if (AuthService.instance.currentUser?.role != 'admin') return const Scaffold(body: Center(child: Text('Administrator access required.')));
    return Scaffold(appBar: AppBar(title: const Text('User Management'), actions: [IconButton(onPressed: _add, icon: const Icon(Icons.person_add))]), body: ListView(children: [for (final x in users) ListTile(leading: const Icon(Icons.person), title: Text(x['display_name'] as String), subtitle: Text('${x['username']} • ${x['role']}'), trailing: Icon((x['active'] as int) == 1 ? Icons.check_circle : Icons.block))]));
  }
}
