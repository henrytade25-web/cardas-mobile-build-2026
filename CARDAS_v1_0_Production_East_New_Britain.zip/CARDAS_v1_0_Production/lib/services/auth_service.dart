import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../database/database_service.dart';
import '../models/app_user.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();
  AppUser? currentUser;

  String hashPassword(String password) => sha256.convert(utf8.encode(password)).toString();

  Future<bool> hasUsers() => DatabaseService.instance.hasUsers();

  Future<void> createUser({required String username, required String displayName, required String role, required String password}) async {
    await DatabaseService.instance.createUser(username: username.trim(), displayName: displayName.trim(), role: role, passwordHash: hashPassword(password));
  }

  Future<bool> login(String username, String password) async {
    final row = await DatabaseService.instance.findUser(username.trim());
    if (row == null) return false;
    final user = AppUser.fromMap(row);
    if (!user.active || user.passwordHash != hashPassword(password)) return false;
    currentUser = user;
    await DatabaseService.instance.logAudit(user.username, 'LOGIN', 'Successful login');
    return true;
  }

  Future<void> logout() async {
    final u = currentUser;
    if (u != null) await DatabaseService.instance.logAudit(u.username, 'LOGOUT', 'User logged out');
    currentUser = null;
  }
}
