import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../database/database_service.dart';

class BackupService {
  BackupService._();
  static final instance = BackupService._();

  Future<File> createBackup() async {
    final data = await DatabaseService.instance.exportAllData();
    final root = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(root.path, 'cardas_backups'))..createSync(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    final file = File(p.join(folder.path, 'CARDAS_backup_$stamp.json'));
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    return file;
  }

  Future<String?> pickAndRestoreBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
    if (result == null || result.files.single.path == null) return null;
    final file = File(result.files.single.path!);
    final data = jsonDecode(await file.readAsString());
    if (data is! Map<String, dynamic> || data['format'] != 'CARDAS_BACKUP_V1') {
      throw const FormatException('Not a valid CARDAS backup file.');
    }
    await DatabaseService.instance.restoreAllData(data);
    return file.path;
  }
}
