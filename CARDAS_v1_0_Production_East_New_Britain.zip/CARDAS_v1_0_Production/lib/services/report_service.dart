import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../database/database_service.dart';
import '../models/incident.dart';
import '../models/household.dart';
import '../models/warehouse_item.dart';

class ReportService {
  ReportService._();
  static final instance = ReportService._();

  Future<List<Household>> households() => DatabaseService.instance.getHouseholds();
  Future<List<Incident>> incidents() => DatabaseService.instance.getIncidents();
  Future<List<WarehouseItem>> warehouse() => DatabaseService.instance.getWarehouse();

  String _csv(String value) => '"${value.replaceAll('"', '""')}"';

  Future<String> exportIncidentsCsv() async {
    final rows = await incidents();
    final buffer = StringBuffer();
    buffer.writeln('Incident Code,District,Parish,Village,Hazard,Priority,Latitude,Longitude,Description,Created At');
    for (final x in rows) {
      buffer.writeln([
        _csv(x.incidentCode), _csv(x.district), _csv(x.parish), _csv(x.village),
        _csv(x.hazard), _csv(x.priority), x.latitude ?? '', x.longitude ?? '',
        _csv(x.description), _csv(x.createdAt.toIso8601String()),
      ].join(','));
    }
    return _saveText('cardas_incidents_${_stamp()}.csv', utf8.encode(buffer.toString()));
  }

  Future<String> exportHouseholdsCsv() async {
    final rows = await households();
    final buffer = StringBuffer();
    buffer.writeln('Beneficiary ID,Family Head,Family Size,District,Parish,Village,Immediate Needs,Created At');
    for (final x in rows) {
      buffer.writeln([
        _csv(x.beneficiaryId), _csv(x.familyHead), x.familySize, _csv(x.district),
        _csv(x.parish), _csv(x.village), _csv(x.immediateNeeds), _csv(x.createdAt.toIso8601String()),
      ].join(','));
    }
    return _saveText('cardas_households_${_stamp()}.csv', utf8.encode(buffer.toString()));
  }

  Future<String> exportWarehouseCsv() async {
    final rows = await warehouse();
    final buffer = StringBuffer();
    buffer.writeln('Item,Category,Quantity,Unit');
    for (final x in rows) {
      buffer.writeln([_csv(x.itemName), _csv(x.category), x.quantity, _csv(x.unit)].join(','));
    }
    return _saveText('cardas_warehouse_${_stamp()}.csv', utf8.encode(buffer.toString()));
  }

  Future<String> _saveText(String filename, List<int> bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(dir.path, 'cardas_exports'));
    await folder.create(recursive: true);
    final file = File(p.join(folder.path, filename));
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  String _stamp() => DateTime.now().toIso8601String().replaceAll(RegExp(r'[:.]'), '-');

  Future<Uint8List> buildSituationReport() async {
    final db = DatabaseService.instance;
    final incidents = await db.getIncidents();
    final households = await db.getHouseholds();
    final stock = await db.getWarehouse();
    final logo = (await rootBundle.load('assets/branding/caritas_rabaul_logo.jpg')).buffer.asUint8List();
    final crest = (await rootBundle.load('assets/branding/archdiocese_rabaul_crest.png')).buffer.asUint8List();

    final doc = pw.Document();
    final now = DateTime.now();
    final critical = incidents.where((x) => x.priority == 'Critical').length;
    final high = incidents.where((x) => x.priority == 'High').length;
    final gps = incidents.where((x) => x.latitude != null && x.longitude != null).length;

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      header: (_) => pw.Row(children: [
        pw.Image(pw.MemoryImage(logo), width: 110, height: 48, fit: pw.BoxFit.contain),
        pw.Spacer(),
        pw.Image(pw.MemoryImage(crest), width: 48, height: 48, fit: pw.BoxFit.contain),
      ]),
      footer: (context) => pw.Align(
        alignment: pw.Alignment.centerRight,
        child: pw.Text('CARDAS • Page ${context.pageNumber}'),
      ),
      build: (_) => [
        pw.SizedBox(height: 12),
        pw.Text('Disaster Situation Report', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.Text('Caritas Rabaul Office • Archdiocese of Rabaul'),
        pw.Text('Generated: ${now.toLocal()}'),
        pw.SizedBox(height: 18),
        pw.Table.fromTextArray(
          headers: const ['Indicator', 'Count'],
          data: [
            ['Registered incidents', '${incidents.length}'],
            ['Critical priority', '$critical'],
            ['High priority', '$high'],
            ['Incidents with GPS', '$gps'],
            ['Registered households', '${households.length}'],
            ['Warehouse item types', '${stock.length}'],
            ['Total stock units', '${stock.fold<int>(0, (sum, x) => sum + x.quantity)}'],
          ],
        ),
        pw.SizedBox(height: 20),
        pw.Text('Incident Register', style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        if (incidents.isEmpty) pw.Text('No incidents have been registered.') else pw.Table.fromTextArray(
          headers: const ['Code', 'Hazard', 'Priority', 'Location', 'GPS'],
          data: incidents.map((x) => [
            x.incidentCode,
            x.hazard,
            x.priority,
            '${x.district} / ${x.parish} / ${x.village}',
            x.latitude == null ? '—' : '${x.latitude!.toStringAsFixed(4)}, ${x.longitude!.toStringAsFixed(4)}',
          ]).toList(),
          cellStyle: const pw.TextStyle(fontSize: 7),
          headerStyle: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 20),
        pw.Text('Household Register', style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        if (households.isEmpty) pw.Text('No households have been registered.') else pw.Table.fromTextArray(
          headers: const ['Beneficiary', 'Family Head', 'Size', 'Location', 'Needs'],
          data: households.map((x) => [
            x.beneficiaryId,
            x.familyHead,
            '${x.familySize}',
            '${x.district} / ${x.parish} / ${x.village}',
            x.immediateNeeds,
          ]).toList(),
          cellStyle: const pw.TextStyle(fontSize: 7),
          headerStyle: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 20),
        pw.Text('Warehouse Snapshot', style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Table.fromTextArray(
          headers: const ['Item', 'Category', 'Quantity', 'Unit'],
          data: stock.map((x) => [x.itemName, x.category, '${x.quantity}', x.unit]).toList(),
          cellStyle: const pw.TextStyle(fontSize: 8),
          headerStyle: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 20),
        pw.Text('Operational note: this report reflects data stored on this device at the time of generation.'),
      ],
    ));
    return doc.save();
  }

  Future<String> saveSituationReport() async {
    final bytes = await buildSituationReport();
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory(p.join(dir.path, 'cardas_exports'));
    await folder.create(recursive: true);
    final file = File(p.join(folder.path, 'cardas_situation_report_${_stamp()}.pdf'));
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  Future<void> shareSituationReport() async {
    final bytes = await buildSituationReport();
    await Printing.sharePdf(bytes: bytes, filename: 'cardas_situation_report.pdf');
  }
}
