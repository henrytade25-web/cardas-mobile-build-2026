import '../database/database_service.dart';

class SyncService {
  SyncService._();
  static final instance = SyncService._();

  Future<int> pendingCount() async => (await DatabaseService.instance.getPendingSync()).length;

  /// Package G deliberately stops at a durable local sync queue. A server endpoint,
  /// authentication scheme, conflict policy and diocesan hosting decision must be
  /// agreed before CARDAS sends field records anywhere.
  Future<String> statusMessage() async {
    final n = await pendingCount();
    return n == 0 ? 'No records waiting for synchronization.' : '$n record(s) waiting in the local sync queue.';
  }
}
