import 'package:flutter/material.dart';

class CardasTheme {
  static const caritasGreen = Color(0xFF146B3A);
  static const limeAccent = Color(0xFFB7D300);

  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: caritasGreen,
      brightness: Brightness.light,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: const Color(0xFFF7F8F6),
      appBarTheme: const AppBarTheme(centerTitle: false),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
      ),
    );
  }
}
