import 'package:flutter_test/flutter_test.dart';
void main(){test('CARDAS package placeholder test',(){expect(1,1);});}
