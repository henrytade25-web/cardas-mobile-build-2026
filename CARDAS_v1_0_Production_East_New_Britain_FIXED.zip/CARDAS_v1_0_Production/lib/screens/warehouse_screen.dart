import 'package:flutter/material.dart';

import '../database/database_service.dart';
import '../models/warehouse_item.dart';

class WarehouseScreen extends StatefulWidget {
  const WarehouseScreen({super.key});

  @override
  State<WarehouseScreen> createState() => _WarehouseScreenState();
}

class _WarehouseScreenState extends State<WarehouseScreen> {
  List<WarehouseItem> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final loadedItems = await DatabaseService.instance.getWarehouse();
    if (!mounted) return;
    setState(() {
      items = loadedItems;
    });
  }

  Future<void> change(WarehouseItem item, int delta) async {
    final quantity = item.quantity + delta;
    if (quantity < 0) return;

    await DatabaseService.instance.updateWarehouseQuantity(item.id!, quantity);
    await load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Warehouse Inventory'),
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          children: items.map((item) {
            return Card(
              margin: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 6,
              ),
              child: ListTile(
                title: Text(item.itemName),
                subtitle: Text('${item.category} • ${item.unit}'),
                trailing: SizedBox(
                  width: 140,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: () => change(item, -1),
                        icon: const Icon(Icons.remove),
                      ),
                      Text(
                        '${item.quantity}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        onPressed: () => change(item, 1),
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
